/** 
Name	: Prashant Saxena
Rollno  : 43
Subject : Network Security
**/

import java.util.*;
import java.io.*;
import java.net.*;

public class Client
{
	public static void main(String args[]) throws IOException
	{
		Scanner scan = new Scanner(System.in);
		Socket cs = new Socket("127.0.0.1",3333);
		
		DataOutputStream out = new DataOutputStream(cs.getOutputStream());
		System.out.println("Client Started...");
		while(true)
		{
			System.out.println("Enter Message: ");
			String msg = scan.nextLine();
			
			out.writeUTF(msg);
			if(msg.equalsIgnoreCase("exit"))
			{
				System.out.println("Client Ended..");
				break;
			}
			System.out.println("String: " + msg + " sent Successfully to Server");
		}
	}
}