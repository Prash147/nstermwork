/** 
Name	: Prashant Saxena
Rollno  : 43
Subject : Network Security
**/

import java.io.*;
import java.net.*;

public class Server
{
	public static void main(String args[])
	{
		try
		{
			System.out.println("Server Started...");
			ServerSocket ss = new ServerSocket(3456);
			Socket con = ss.accept();
			
			DataInputStream input = new DataInputStream(con.getInputStream());
			String msg = input.readUTF();
			
			System.out.println("Message Received is: " + msg);
		}
		catch(Exception e)
		{
			System.out.println("Something went wrong: " + e);
		}
	}
}