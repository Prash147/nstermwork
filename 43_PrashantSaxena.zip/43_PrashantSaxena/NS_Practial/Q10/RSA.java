/** 
Name	: Prashant Saxena
Rollno  : 43
Subject : Network Security
**/

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.*;

public class RSA
{
    public static void main(String[] args) throws Exception
	{
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(4096);
        KeyPair keyPair = keyPairGenerator.generateKeyPair();
        
        PublicKey publicKey = keyPair.getPublic();
        PrivateKey privateKey = keyPair.getPrivate();
            
        byte[] pub_key = publicKey.getEncoded();
        FileOutputStream pub_k = new FileOutputStream("pub.pub");
        pub_k.write(pub_key);
        pub_k.close();
        
		byte[] pri_key = privateKey.getEncoded();
        FileOutputStream pri_k = new FileOutputStream("pri.key");
        pri_k.write(pri_key);
        pri_k.close(); 
        
        //Restoring Keys
        byte[] bytes = Files.readAllBytes(Paths.get("pub.pub"));
        X509EncodedKeySpec ks = new X509EncodedKeySpec(bytes);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        PublicKey pub = kf.generatePublic(ks);
        
        byte[] bytes1 = Files.readAllBytes(Paths.get("pri.key"));
        PKCS8EncodedKeySpec ks1 = new PKCS8EncodedKeySpec(bytes1);
        KeyFactory kf1 = KeyFactory.getInstance("RSA");
        PrivateKey pvt = kf1.generatePrivate(ks1);
        
        //Encryption
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.ENCRYPT_MODE, pvt);
        
		try(FileInputStream in = new FileInputStream("input.txt");
		FileOutputStream out = new FileOutputStream("encryptFile.txt"))
		{
            processFile(cipher, in, out);
        }

		//Decryption
        Cipher cipher1 = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher1.init(Cipher.DECRYPT_MODE, pub);
        
		try(FileInputStream in = new FileInputStream("encryptFile.txt");
        FileOutputStream out = new FileOutputStream("decryptFile.txt"))
		{
            processFile(cipher1, in, out);
        }
        
		System.out.println("Process Done Successfully\nFiles generated are as follows:\nPublic Key: pub.pub\nPrivate Key: pri.key\nSource File: input.txt\nEncrypted File: encryptFile.txt\nDecrypted File: decryptFile.txt");
    }
	static private void processFile(Cipher ci,InputStream in,OutputStream out)throws Exception
    {
    	byte[] ibuf = new byte[1024];
    	int len;
    	while ((len = in.read(ibuf)) != -1)
		{
    	    byte[] obuf = ci.update(ibuf, 0, len);
    	    if ( obuf != null ) out.write(obuf);
    	}
  	    byte[] obuf = ci.doFinal();
   	    if ( obuf != null ) out.write(obuf);
    }   
}