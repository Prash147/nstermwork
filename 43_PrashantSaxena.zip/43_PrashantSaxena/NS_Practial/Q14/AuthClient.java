/** 
Name	: Prashant Saxena
Rollno  : 43
Subject : Network Security
**/

import java.io.*;
import java.util.*;
import java.net.*;

public class AuthClient
{
    private static String key = "TIMES";
    
	public static void main(String[] args) throws IOException
    {
		System.out.println("Client Started...");
        Scanner scan = new Scanner(System.in);
		Socket cs = new Socket("localhost",1234);
		
		System.out.print("\nEnter Username: ");
		String uname = scan.nextLine();
		
		System.out.print("\nEnter password: ");
		String password = scan.nextLine().replace(" ","$");
        String encPassword = encrypt(password);
		System.out.println("Username: " + uname + " Password: " + encPassword);
		DataOutputStream out = new DataOutputStream(cs.getOutputStream());
		out.writeUTF(uname + "_@_" + encPassword);
		
		DataInputStream input = new DataInputStream(cs.getInputStream());
		String receivedMsg = input.readUTF();

        System.out.println("Result: "+ receivedMsg);
    }
	
	public static String encrypt(String input)
	{
		StringBuilder msg = new StringBuilder(input);
		StringBuilder cipher = new StringBuilder();
		
		char encrypt_array[][];
		if((input.length()%key.length())==0)
			encrypt_array = new char[input.length()/key.length()][key.length()];
		else
			encrypt_array = new char[(input.length()/key.length())+1][key.length()];
		
		char OriginalKey[] = key.toCharArray();
		char SortedKey[] = OriginalKey;
		Arrays.sort(SortedKey);
		
		int row=0,col=0;
		while(msg.length()>0)
		{
			encrypt_array[row][col] = msg.charAt(0);
			msg.deleteCharAt(0);
			
			if(col==key.length()-1) {
				col=0;
				row+=1;
			}
			else
				col+=1;
		}
		
		for(int i=0;i<encrypt_array.length;i++)
		{
			for(int j=0;j<encrypt_array[0].length;j++)
			{
				if(encrypt_array[i][j] != '\0')
					continue;
				else
					encrypt_array[i][j] = '@';
			}
		}
		for(int i=0;i<SortedKey.length;i++)
		{
			int column = key.indexOf(SortedKey[i]+"");
			
			for(int j=0;j<encrypt_array.length;j++)
			{
				cipher.append(encrypt_array[j][column]);
			}
		}
		
		return cipher+"";
	}
}