/** 
Name	: Prashant Saxena
Rollno  : 43
Subject : Network Security
**/

import java.io.*;
import java.util.*;
import java.net.*;

public class AuthServer
{
    private static String key = "TIMES";
    
	public static void main(String[] args) throws IOException
    {
		System.out.println("Server Started...");
		
		ServerSocket ss = new ServerSocket(1234);	
		Socket cons = ss.accept();

		DataInputStream input = new DataInputStream(cons.getInputStream());
		String receivedMsg = input.readUTF();
		
		String uname = receivedMsg.split("_@_")[0];
		String password = receivedMsg.split("_@_")[1];

        String decPassword = decrypt(password);
		try
		{
			BufferedReader br = new BufferedReader(new FileReader("users.txt"));
			String temp="";
			
			DataOutputStream out = new DataOutputStream(cons.getOutputStream());
			int flag = 0;
			while((temp = br.readLine()) != null)
			{
				if(temp.trim().equals(uname.trim() + "_@_" + decPassword.trim()))
				{
					flag = 1;
					out.writeUTF("Login Successfully..");
					System.out.println("Valid User");
					break;
				}
			}
			if(flag==0)
			{
				out.writeUTF("Invalid Username or password");
				System.out.println("Invalid User");
			}
		}
		catch(Exception e)
		{
			System.out.println("Error Related to Files: " + e);
		}
    }
	
	public static String decrypt(String str)
	{
		StringBuilder msg = new StringBuilder();
		StringBuilder cipher = new StringBuilder(str);
		char decrypt_array[][] = new char[str.length()/key.length()][key.length()];
		
		char SortedKey[] = key.toCharArray();
		Arrays.sort(SortedKey);
		
		for(int i=0;i<SortedKey.length;i++)
		{
			int column = key.indexOf(SortedKey[i]+"");
			
			for(int j=0;j<decrypt_array.length;j++)
			{
				decrypt_array[j][column] = cipher.charAt(0);
				cipher.deleteCharAt(0);
			}
		}
		
		for(int i=0;i<decrypt_array.length;i++)
		{
			for(int j=0;j<decrypt_array[0].length;j++)
				msg.append(decrypt_array[i][j]);
		}
		
		return (msg+"").replace("@"," ");
	}
}