/** 
Name	: Prashant Saxena
Rollno  : 43
Subject : Network Security
**/

import java.util.*;

public class SubCipher
{
	public static String encrypt(String input,int key)
	{
		StringBuilder cipher = new StringBuilder();
		
		for(int i=0;i<input.length();i++)
		{
			if(input.charAt(i)=='$')
			{
				cipher.append("$");
				continue;
			}
			else if((int)input.charAt(i)>=65 && (int)input.charAt(i)<=91)
			{
				if((int)input.charAt(i)+key>90)
				{
					int temp = (int)input.charAt(i)+key-90;
					cipher.append((char)(64+temp));
				}
				else
					cipher.append((char)((int)input.charAt(i)+key));
			}
			else
			{
				if((int)input.charAt(i)+key>122)
				{
					int temp = (int)input.charAt(i)+key-122;
					cipher.append((char)(96+temp));
				}
				else
					cipher.append((char)((int)input.charAt(i)+key));
			}
		}
		
		return cipher+"";
	}
	
	public static String decrypt(String cipher,int key)
	{
		StringBuilder msg = new StringBuilder();
		
		for(int i=0;i<cipher.length();i++)
		{
			if(cipher.charAt(i)=='$')
			{
				msg.append("$");
				continue;
			}
			else if((int)cipher.charAt(i)>=65 && (int)cipher.charAt(i)<=91)
			{
				if((int)cipher.charAt(i)-key<65)
				{
					int temp = 65-((int)cipher.charAt(i)-key);
					msg.append((char)(91-temp));
				}
				else
					msg.append((char)((int)cipher.charAt(i)-key));
			}
			else
			{
				if((int)cipher.charAt(i)-key<97)
				{
					int temp = 97-((int)cipher.charAt(i)-key);
					msg.append((char)(123-temp));
				}
				else
					msg.append((char)((int)cipher.charAt(i)-key));
			}
		}
		
		return msg+"";
	}
	
	public static void main(String args[])
	{
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Message: ");
		String input = scan.nextLine().replace(" ","$");
		
		System.out.println("Enter Key: ");
		int key = scan.nextInt();
		
		
		String cipher = encrypt(input,key);
		System.out.println("Encrypted Message: " + cipher);
		
		String msg = decrypt(cipher,key);
		System.out.println("Decrypted Message: " + msg.replace("$"," "));
	}
}