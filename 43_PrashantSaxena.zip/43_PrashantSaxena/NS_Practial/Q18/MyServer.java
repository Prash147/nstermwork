/** 
Name	: Prashant Saxena
Rollno  : 43
Subject : Network Security
**/

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import javax.crypto.spec.SecretKeySpec;

public class MyServer
{
    static SecretKeySpec serverkey,KDCkey;
	
    public static void main(String[] args) throws Exception
	{
        System.out.println("Server Started...");
        serverkey = new SecretKeySpec("87654321".getBytes(),"DES");
		KDCkey = new SecretKeySpec("87654321".getBytes(),"DES");
		
        ServerSocket ss = new ServerSocket(8888);
		Socket con = ss.accept();
        
		DataInputStream input = new DataInputStream(con.getInputStream());
		String sessionkey = input.readUTF();
		
		System.out.println("Connecting Client to Communicate..");
		
		ss = new ServerSocket(8811);
		con = ss.accept();		
		
		System.out.println("Client Connected..");
		System.out.println("Receiving Message from Client..");
				
		input = new DataInputStream(con.getInputStream());
		String ClientInput = input.readUTF();
			
		String client_session_key = ClientInput.split("_@_")[1];
		String message = ClientInput.split("_@_")[0];
				
		if(sessionkey.equals(client_session_key))
		{
			System.out.println("Message Received..");
			System.out.println("Message: " + message);
		}				
		else
			System.out.println("Message received from invalid Client..");
	}
}