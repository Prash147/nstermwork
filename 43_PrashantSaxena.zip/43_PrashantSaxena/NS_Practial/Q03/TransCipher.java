/** 
Name	: Prashant Saxena
Rollno  : 43
Subject : Network Security
**/

import java.util.*;

public class TransCipher
{
	public static String encrypt(String input, String key)
	{
		StringBuilder msg = new StringBuilder(input);
		StringBuilder cipher = new StringBuilder();
		
		char encrypt_array[][];
		if((input.length()%key.length())==0)
			encrypt_array = new char[input.length()/key.length()][key.length()];
		else
			encrypt_array = new char[(input.length()/key.length())+1][key.length()];
		
		char OriginalKey[] = key.toCharArray();
		char SortedKey[] = OriginalKey;
		Arrays.sort(SortedKey);
		
		int row=0,col=0;
		while(msg.length()>0)
		{
			encrypt_array[row][col] = msg.charAt(0);
			msg.deleteCharAt(0);
			
			if(col==key.length()-1) {
				col=0;
				row+=1;
			}
			else
				col+=1;
		}
		
		for(int i=0;i<encrypt_array.length;i++)
		{
			for(int j=0;j<encrypt_array[0].length;j++)
			{
				if(encrypt_array[i][j] != '\0')
					continue;
				else
					encrypt_array[i][j] = '@';
			}
		}
		for(int i=0;i<SortedKey.length;i++)
		{
			int column = key.indexOf(SortedKey[i]+"");
			
			for(int j=0;j<encrypt_array.length;j++)
			{
				cipher.append(encrypt_array[j][column]);
			}
		}
		
		return cipher+"";
	}
	
	public static String decrypt(String str, String key)
	{
		StringBuilder msg = new StringBuilder();
		StringBuilder cipher = new StringBuilder(str);
		char decrypt_array[][] = new char[str.length()/key.length()][key.length()];
		
		char SortedKey[] = key.toCharArray();
		Arrays.sort(SortedKey);
		
		for(int i=0;i<SortedKey.length;i++)
		{
			int column = key.indexOf(SortedKey[i]+"");
			
			for(int j=0;j<decrypt_array.length;j++)
			{
				decrypt_array[j][column] = cipher.charAt(0);
				cipher.deleteCharAt(0);
			}
		}
		
		for(int i=0;i<decrypt_array.length;i++)
		{
			for(int j=0;j<decrypt_array[0].length;j++)
				msg.append(decrypt_array[i][j]);
		}
		
		return (msg+"").replace("@"," ");
	}
	
	public static void main(String args[])
	{
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Message: ");
		String input = scan.nextLine().replace(" ","$");
		
		System.out.println("Enter Key: ");
		String key = scan.next();
		
		
		String cipher = encrypt(input,key);
		System.out.println("\n\nEncrypted Message: " + cipher);
		
		String msg = decrypt(cipher,key);
		System.out.println("Decrypted Message: " + msg.replace("$"," "));
		
	}
}