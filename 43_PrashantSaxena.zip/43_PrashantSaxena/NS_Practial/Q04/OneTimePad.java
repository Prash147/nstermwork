/** 
Name	: Prashant Saxena
Rollno  : 43
Subject : Network Security
**/

import java.io.*;
import java.util.*;

public class OneTimePad
{
	public static void main(String args[]) throws IOException
	{
		Scanner scan = new Scanner(System.in);
		String pad = new BufferedReader(new FileReader("PadKey.txt")).readLine();
		
		System.out.println("Enter Message: ");
		String plaintxt = scan.nextLine();
		
		String binary_str = convertStringToBinary(plaintxt);
		
		StringBuffer cipher = new StringBuffer();
		StringBuffer msg = new StringBuffer();
		
	    for (int i = 0; i < binary_str.length(); i++)
			cipher.append(binary_str.charAt(i)^pad.charAt(i));
		
	    System.out.println("Encrypted Message: " + cipher);
	    
		String message="";
		
	    for(int i=0;i<cipher.length();i++)
	    	msg.append(cipher.charAt(i)^pad.charAt(i));
	    
	    for (int i=0; i<msg.length()/8;i++)
		{
	        int a = Integer.parseInt(msg.substring(8*i,8*(i+1)),2);
	        message += (char)(a);
	    }

	    System.out.println("Decrypted Message: " + message);
	}
	
	public static String convertStringToBinary(String input)
	{
        StringBuilder result = new StringBuilder();
        char[] chars = input.toCharArray();
        for (char aChar : chars)
            result.append(String.format("%8s", Integer.toBinaryString(aChar)).replaceAll(" ", "0"));
        
        return result.toString();
    }
}